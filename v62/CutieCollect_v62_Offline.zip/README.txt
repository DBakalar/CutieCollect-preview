Cutie Collect v62 — Offline Play

Extract the entire ZIP to a folder. Open index.html in Google Chrome.
Keep the assets folder beside index.html so creature and notebook art loads.
Your player progress is saved locally by Chrome for this file location.
